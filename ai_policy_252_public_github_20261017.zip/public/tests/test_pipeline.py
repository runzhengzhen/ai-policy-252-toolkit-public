import tempfile
import unittest
from pathlib import Path
import penman
from src.io_utils import write_csv, text_hash
from src.preprocess import split_sentences, prepare
from src.mrp_conversion import mrp_to_penman_string
from src.semantics import annotate_stance
from run import validate_cached_predictions


class PipelineContractTests(unittest.TestCase):
    def test_sentence_boundary(self):
        self.assertEqual(list(split_sentences("甲；乙。\n丙！")), ["甲；", "乙。", "丙！"])

    def test_explicit_blank_analysis_text_stays_blank(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            corpus = root / "corpus.csv"
            write_csv(corpus, [{"record_id": "P1", "title": "题名", "text": "网页残留", "analysis_text": ""}],
                      ["record_id", "title", "text", "analysis_text"])
            sentences, audit = prepare(corpus, root)
            self.assertFalse(sentences)
            self.assertEqual(audit["empty_records"], 1)

    def test_cache_content_mismatch_is_rejected(self):
        sentences = [{"doc_id": "P1", "sentence_id": "P1_0", "sentence_sha256": text_hash("new")}]
        predictions = [{"doc_id": "P1", "sentence_id": "P1_0", "sentence_sha256": text_hash("old"), "amr_string": "<NAN>"}]
        with self.assertRaises(ValueError):
            validate_cached_predictions(sentences, predictions)

    def test_negative_node_becomes_polarity_attribute(self):
        mrp = {"nodes": [{"id": 0, "label": "使用-01"}, {"id": 1, "label": "作者"}, {"id": 2, "label": "-"}],
               "edges": [{"source": 0, "target": 1, "label": "arg0"}, {"source": 0, "target": 2, "label": "polarity"}], "tops": [0]}
        encoded = mrp_to_penman_string(mrp, ["作者", "不用"])
        graph = penman.decode(encoded)
        self.assertIn(("x0", ":polarity", "-"), graph.triples)
        self.assertNotIn(("x2", ":instance", "-"), graph.triples)

    def test_disconnected_components_survive(self):
        mrp = {"nodes": [{"id": 0, "label": "使用-01"}, {"id": 1, "label": "作者"}, {"id": 2, "label": "编辑部"}],
               "edges": [{"source": 0, "target": 1, "label": "arg0"}], "tops": [0]}
        encoded = mrp_to_penman_string(mrp, ["作者", "使用", "编辑部"])
        self.assertIn("multi-sentence", encoded)
        self.assertIn("编辑部", encoded)

    def test_double_negation_and_unknown_frame(self):
        row = {"predicate_va": "TEST", "predicate_pol": "-", "parent_predicate_pol": "-"}
        self.assertEqual(annotate_stance(row, {"TEST": "A"}), "A")
        row["parent_predicate_pol"] = "+"
        self.assertEqual(annotate_stance(row, {"TEST": "A"}), "B")
        self.assertEqual(annotate_stance({"predicate_va": ""}, {}), "N")


if __name__ == "__main__":
    unittest.main()
