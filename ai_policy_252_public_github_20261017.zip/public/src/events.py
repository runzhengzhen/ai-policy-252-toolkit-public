"""Upstream soteu event extraction, with per-sentence failure accounting."""
import pandas as pd
import penman
from penman.models import noop
from .amr_graphs import (penman_to_igraph, add_parent_predicates_to_graph,
                         add_predicate_graph, add_event_subgraphs)
from .helpers import subgraph_to_csvrows, rowlist_to_df
from .io_utils import write_csv, write_json


def build_events(predictions, output):
    rows, failures = [], []
    no_events = []
    for index, prediction in enumerate(predictions):
        sid = prediction["sentence_id"]
        amr = prediction["amr_string"]
        if not amr or amr == "<NAN>":
            continue
        try:
            obj = penman.decode(amr, model=noop.model)
            if not obj.edges():
                no_events.append(sid)
                continue
            graph = penman_to_igraph(obj, amr)
            graph = add_parent_predicates_to_graph(graph)
            graph = add_predicate_graph(graph)
            graph = add_event_subgraphs(graph, sid)
            current = []
            if "subgraphs" in graph.attributes():
                for subgraph_id, subgraph in graph["subgraphs"].items():
                    current.extend(subgraph_to_csvrows(subgraph, subgraph_id))
            if not current:
                no_events.append(sid)
            rows.extend(current)
        except Exception as error:
            failures.append({"sentence_id": sid, "error": type(error).__name__ + ": " + str(error)})
        if index and index % 1000 == 0:
            print("Event extraction: {}/{} sentences".format(index, len(predictions)), flush=True)
    if not rows:
        raise RuntimeError("No events extracted; see AMR inputs and dependency diagnostics")
    frame = rowlist_to_df(rows)
    frame = frame.sort_values(["sentence_id", "event_id", "predicate_pb"], kind="stable").reset_index(drop=True)
    frame.to_csv(output / "amr_events.csv", index=False, encoding="utf-8-sig", lineterminator="\n")
    write_csv(output / "event_extraction_errors.csv", failures, ["sentence_id", "error"])
    write_csv(output / "graphs_without_events.csv", [{"sentence_id": sid} for sid in no_events], ["sentence_id"])
    audit = {"event_rows": len(frame), "unique_event_ids": frame["event_id"].nunique(),
             "sentences_with_events": frame["sentence_id"].nunique(),
             "records_with_events": frame["sentence_id"].str.rsplit("_", n=1).str[0].nunique(),
             "graph_extraction_failures": len(failures), "graphs_without_events": len(no_events)}
    write_json(output / "event_extraction_audit.json", {key: int(value) for key, value in audit.items()})
    return frame, audit
