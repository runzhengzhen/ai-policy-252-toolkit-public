"""Fresh AMR inference; checkpoint download and all caches are project-relative."""
import json
import os
import random
import shutil
import time
import urllib.request
import zipfile
from pathlib import Path
from .io_utils import ROOT, write_csv, write_json, sha256

AMR_REL = "thirdparty/download.hanlp.com/amr/extra/amr-zho-mengzi-base_20220415_101941"
TOK_REL = "tok/coarse_electra_small_20220616_012050"


def ensure_models(cache):
    cache = Path(cache)
    cache.mkdir(parents=True, exist_ok=True)
    shutil.copytree(ROOT / "resources/hanlp-seed", cache, dirs_exist_ok=True)
    specs = json.loads((ROOT / "resources/model_downloads.json").read_text(encoding="utf-8"))
    for spec in specs:
        target = cache / spec["relative_directory"]
        if (target / spec["required_file"]).is_file() and sha256(target / spec["required_file"]) == spec["required_file_sha256"]:
            continue
        archive = Path(str(target) + ".zip")
        archive.parent.mkdir(parents=True, exist_ok=True)
        if not archive.is_file() or sha256(archive) != spec["archive_sha256"]:
            print("Downloading {}".format(spec["url"]), flush=True)
            temporary = archive.with_suffix(".download")
            with urllib.request.urlopen(spec["url"], timeout=180) as response, temporary.open("wb") as output:
                shutil.copyfileobj(response, output, length=1024 * 1024)
            if sha256(temporary) != spec["archive_sha256"]:
                raise RuntimeError("Model archive checksum mismatch: " + archive.name)
            temporary.replace(archive)
        with zipfile.ZipFile(archive) as zipped:
            destination = target.parent.resolve()
            for info in zipped.infolist():
                path = (destination / info.filename).resolve()
                if destination not in path.parents and path != destination:
                    raise ValueError("Unsafe model archive path")
            zipped.extractall(target.parent)
        if not (target / spec["required_file"]).is_file():
            raise RuntimeError("Expected model file missing after extraction: " + str(target))
        if sha256(target / spec["required_file"]) != spec["required_file_sha256"]:
            raise RuntimeError("Extracted model checksum mismatch: " + str(target))
    return cache


def parse_fresh(sentences, output, model_cache=None, batch_size=16, limit=None):
    cache = Path(model_cache) if model_cache else ROOT / ".models/hanlp"
    ensure_models(cache)
    os.environ["HANLP_HOME"] = str(cache.resolve())
    os.environ["HF_HUB_CACHE"] = str(ROOT / "resources/huggingface/hub")
    os.environ["HUGGINGFACE_HUB_CACHE"] = os.environ["HF_HUB_CACHE"]
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    os.environ["TOKENIZERS_PARALLELISM"] = "false"
    import numpy as np
    import torch
    import hanlp
    from .mrp_conversion import mrp_to_penman_string
    random.seed(42)
    np.random.seed(42)
    torch.manual_seed(42)
    torch.set_num_threads(2)
    print("Loading Chinese tokenizer and AMR model...", flush=True)
    tokenizer = hanlp.load(str(cache / TOK_REL))
    model = hanlp.load(str(cache / AMR_REL))
    rows = sentences[:limit] if limit is not None else sentences
    unique = list(dict.fromkeys(row["sentence"] for row in rows))
    parsed, errors = {}, []
    started = time.time()
    for start in range(0, len(unique), batch_size):
        batch = unique[start:start + batch_size]
        try:
            tokens = tokenizer(batch)
            graphs = model(tokens)
            if isinstance(graphs, dict):
                graphs = [graphs]
            if len(graphs) != len(batch):
                raise ValueError("Batch output length mismatch")
            for sentence, words, graph in zip(batch, tokens, graphs):
                parsed[sentence] = mrp_to_penman_string(graph, words) or "<NAN>"
        except Exception:
            for sentence in batch:
                try:
                    words = tokenizer(sentence)
                    parsed[sentence] = mrp_to_penman_string(model(words), words) or "<NAN>"
                except Exception as error:
                    parsed[sentence] = "<NAN>"
                    errors.append({"sentence": sentence, "error": type(error).__name__ + ": " + str(error)})
        if start % (batch_size * 10) == 0:
            print("Parsed {}/{} unique sentences ({:.1f}s)".format(
                min(start + batch_size, len(unique)), len(unique), time.time() - started), flush=True)
    predictions = [{"doc_id": row["doc_id"], "sentence_id": row["sentence_id"],
                    "sentence_sha256": row["sentence_sha256"], "amr_string": parsed[row["sentence"]]}
                   for row in rows]
    write_csv(output / "amr_predictions.csv", predictions,
              ["doc_id", "sentence_id", "sentence_sha256", "amr_string"])
    write_csv(output / "amr_parse_errors.csv", errors, ["sentence", "error"])
    write_json(output / "amr_parse_audit.json", {
        "mode": "fresh_model_inference", "sentences": len(rows), "unique_inferences": len(unique),
        "nonempty_graphs": sum(row["amr_string"] != "<NAN>" for row in predictions),
        "failures_or_no_edges": sum(row["amr_string"] == "<NAN>" for row in predictions),
        "model": "MRP2020_AMR_ZHO_MENGZI_BASE", "seed": 42,
        "identical_sentences_share_inference": True,
    })
    return predictions
