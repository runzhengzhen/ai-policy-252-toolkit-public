"""Publication figures using a bundled OFL Chinese font and fixed palette."""
import os
import math
from pathlib import Path
from .io_utils import ROOT

# Palette follows the supplied reference: deep blue, teal, ochre, orange, coral.
PALETTE = ["#264653", "#2A9D8E", "#E9C46B", "#F3A261", "#E66F51"]


def setup():
    os.environ.setdefault("MPLCONFIGDIR", str(ROOT / ".models/matplotlib"))
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    face = ROOT / "resources/fonts/NotoSansSC-Regular.otf"
    font_manager.fontManager.addfont(str(face))
    family = font_manager.FontProperties(fname=str(face)).get_name()
    matplotlib.rcParams.update({"font.family": family, "axes.unicode_minus": False,
                                 "svg.fonttype": "none", "svg.hashsalt": "ai-policy-repro-20261016-effective252",
                                 "font.size": 12})
    return plt


def save_figure(fig, base):
    fig.savefig(str(base) + ".png", dpi=180, bbox_inches="tight", facecolor="white")
    fig.savefig(str(base) + ".svg", bbox_inches="tight", facecolor="white", metadata={"Date": None})


def bar_figure(labels, counts, n, title, base, colors=None):
    plt = setup()
    colors = colors or [PALETTE[index % len(PALETTE)] for index in range(len(labels))]
    fig, ax = plt.subplots(figsize=(11, max(5, len(labels) * 0.62 + 1.8)))
    shares = [count / n * 100 for count in counts]
    bound = max(10, math.ceil(max(shares or [0]) / 10) * 10)
    for index, (label, count, share, color) in enumerate(zip(labels, counts, shares, colors)):
        ax.barh(index, bound, color="#F1F2F0", height=0.64, zorder=2)
        ax.barh(index, share, color=color, height=0.64, zorder=3)
        ax.text(share + bound * 0.012, index, "{}条  {:.1f}%".format(count, share), va="center", fontsize=11)
    ax.set_yticks(range(len(labels)), labels)
    ax.invert_yaxis()
    ax.set_xlim(0, bound * 1.22)
    ticks = list(range(0, bound + 1, max(1, bound // 5)))
    ax.set_xticks(ticks, ["{}%".format(tick) for tick in ticks])
    ax.grid(axis="x", color="#DDE2E3", linestyle=(0, (2, 5)))
    ax.set_axisbelow(True)
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.tick_params(length=0)
    ax.set_title(title, loc="left", pad=22, fontsize=16)
    fig.text(0.02, 0.015, "以政策文本为单位，N={}；百分比以全部记录为分母。".format(n), fontsize=10, color="#777777")
    fig.tight_layout(rect=(0, 0.05, 1, 1))
    save_figure(fig, base)
    plt.close(fig)


def _percent_panel(ax, rows, colors, n, title, note):
    labels = [row[0] for row in rows]
    counts = [row[1] for row in rows]
    shares = [count / n * 100 for count in counts]
    positions = list(range(len(rows)))
    ax.set_xlim(0, 100)
    ax.set_ylim(-0.7, len(rows) - 0.3)
    ax.set_xticks([0, 25, 50, 75, 100], ["0%", "25%", "50%", "75%", "100%"])
    ax.set_yticks(positions, labels)
    ax.tick_params(axis="x", length=0, colors="#90979D", labelsize=10, pad=9)
    ax.tick_params(axis="y", length=0, colors="#4F5960", labelsize=12, pad=14)
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.grid(axis="x", color="#DADFE1", linewidth=1.0, linestyle=(0, (2, 6)))
    ax.set_axisbelow(True)
    for index, (share, count, color) in enumerate(zip(shares, counts, colors)):
        ax.barh(index, 100, height=0.66, color="#F1F2F0", edgecolor="none", zorder=2)
        ax.barh(index, share, height=0.66, color=color, edgecolor="none", zorder=3)
        inside = share >= 17
        x = share - 1.2 if inside else min(share + 1.2, 94)
        ax.text(x, index, "{}条  {:.1f}%".format(count, share), va="center",
                ha="right" if inside else "left", color="white" if inside else "#4F5960",
                fontsize=10.5, zorder=4)
    ax.invert_yaxis()
    ax.set_title(title, loc="left", fontsize=16, color="#181C1F", pad=15)
    ax.text(1.0, -0.23, note, transform=ax.transAxes, ha="right", va="top",
            fontsize=9.5, color="#7E878D")


def combined_descriptive_figure(genres, levels, n, base):
    """Draw the publication-facing combined title/level figure."""
    plt = setup()
    main = ["声明", "启事", "其他/无法判定", "规定", "公告", "规范", "说明", "政策", "通知"]
    by_genre = dict(zip(genres["genre"], genres["count"]))
    other = sum(count for key, count in by_genre.items() if key not in main)
    title_rows = [(key, int(by_genre.get(key, 0))) for key in main if int(by_genre.get(key, 0))]
    title_rows.append(("其他已识别文种", int(other)))
    title_rows.sort(key=lambda item: (-item[1], item[0]))
    title_colors_by_label = {
        "声明": "#E66F51", "启事": "#264653", "其他/无法判定": "#BCC5C7",
        "规定": "#2A9D8E", "公告": "#F3A261", "规范": "#E9C46B",
        "说明": "#264653", "政策": "#2A9D8E", "通知": "#F3A261",
        "其他已识别文种": "#D8DEDF",
    }
    level_order = ["未收录", "CSSCI(南大核心)", "北大核心+CSCD", "科技核心", "北大核心", "其他收录", "CSCD"]
    level_map = dict(zip(levels["journal_level"], levels["count"]))
    level_rows = [(label, int(level_map.get(label, 0))) for label in level_order]
    level_colors = ["#E66F51", "#264653", "#2A9D8E", "#F3A261", "#E9C46B", "#F3A261", "#2A9D8E"]

    fig = plt.figure(figsize=(16.67, 12.5), dpi=120, facecolor="white")
    fig.text(0.055, 0.955, "学术出版AI政策的标题文种与发布主体等级", fontsize=26,
             color="#181C1F", va="center")
    fig.text(0.055, 0.918, "{}条有效政策文本的描述性分布".format(n), fontsize=15,
             color="#264653", va="center")
    statement_notice = int(by_genre.get("声明", 0) + by_genre.get("启事", 0))
    fig.text(0.055, 0.875, "标题：“声明”与“启事”合计{}条（{:.1f}%）".format(statement_notice, statement_notice / n * 100),
             fontsize=12, color="#E66F51", va="center")
    fig.text(0.43, 0.875, "等级：“未收录”{}条（{:.1f}%）".format(level_map.get("未收录", 0), level_map.get("未收录", 0) / n * 100),
             fontsize=12, color="#264653", va="center")

    ax_title = fig.add_axes((0.285, 0.505, 0.615, 0.315))
    _percent_panel(ax_title, title_rows, [title_colors_by_label[label] for label, _ in title_rows], n,
                   "A  标题文种", "占全部{}条政策的比例；“规范”作为扩充识别的标题形式单列".format(n))
    ax_level = fig.add_axes((0.285, 0.115, 0.615, 0.285))
    _percent_panel(ax_level, level_rows, level_colors, n, "B  发布主体的期刊等级",
                   "占全部{}条政策的比例；“其他收录”表示已查到但不属于主要目录".format(n))
    fig.text(0.055, 0.06,
             "注：统计单位均为政策文本，不按联合发布涉及的期刊数量重复拆分。标题题名已依据原始正文/页面标题复核；投稿须知页面中的AI条款按“须知”计入。",
             fontsize=10.5, color="#7E878D", va="center")
    fig.text(0.055, 0.034,
             "数据来源：有效政策文本及其冻结元数据；没有可核验正文的登记记录不进入分母。",
             fontsize=10.5, color="#7E878D", va="center")
    fig.tight_layout(rect=(0.02, 0.08, 0.98, 0.91))
    save_figure(fig, base)
    plt.close(fig)


def ego_figure(edges, actor, base):
    plt = setup()
    import networkx as nx
    selected = edges[(edges["source"].eq(actor) | edges["target"].eq(actor))
                     & edges["source"].ne(edges["target"]) & edges["weight"].ge(2)].head(35)
    fig, ax = plt.subplots(figsize=(12, 9))
    if selected.empty:
        ax.text(0.5, 0.5, "无满足阈值的关系", ha="center", va="center")
    else:
        graph = nx.DiGraph()
        for row in selected.itertuples(index=False):
            graph.add_edge(row.source, row.target, weight=row.weight, score=row.score)
        layout = nx.spring_layout(graph, seed=42, k=1.5)
        labels = {node: node if len(node) <= 12 else node[:11] + "…" for node in graph.nodes}
        node_colors = [PALETTE[1] if node == actor else "#E7EEEE" for node in graph.nodes]
        nx.draw_networkx_nodes(graph, layout, node_color=node_colors, node_size=1100, edgecolors="#C2CCCE", ax=ax)
        for node, text in labels.items():
            ax.text(*layout[node], text, ha="center", va="center", color="white" if node == actor else "#264653", fontsize=9)
        ordered = list(graph.edges(data=True))
        nx.draw_networkx_edges(graph, layout, ax=ax, arrows=True, arrowsize=16, alpha=0.7,
                               edge_color=[row[2]["score"] for row in ordered], edge_cmap=plt.get_cmap("RdBu"),
                               edge_vmin=-1, edge_vmax=1,
                               width=[1 + 0.35 * math.sqrt(row[2]["weight"]) for row in ordered],
                               connectionstyle="arc3,rad=0.08", node_size=1100)
    ax.set_title("以{}为中心的行动关系".format(actor.strip("【】")), fontsize=17)
    ax.axis("off")
    fig.text(0.5, 0.025, "红：施压或冲突；蓝：支持。仅绘权重≥2的最强35条相关边；完整边表见tables目录。",
             ha="center", fontsize=10, color="#666666")
    fig.tight_layout(rect=(0.02, 0.05, 0.98, 0.98))
    save_figure(fig, base)
    plt.close(fig)


def draw_all(genres, levels, years, edges, output, n):
    from .semantics import ACTORS
    main = ["声明", "启事", "规定", "公告", "说明", "通知", "规范"]
    by_genre = dict(zip(genres["genre"], genres["count"]))
    other = sum(count for key, count in by_genre.items() if key not in main + ["其他/无法判定"])
    title_rows = [(key, by_genre.get(key, 0)) for key in main if by_genre.get(key, 0)]
    if other:
        title_rows.append(("其他已识别文种", other))
    if by_genre.get("其他/无法判定", 0):
        title_rows.append(("其他/无法判定", by_genre["其他/无法判定"]))
    title_rows.sort(key=lambda item: (-item[1], item[0]))
    colors = ["#BCC5C7" if key.startswith("其他") else PALETTE[main.index(key) % len(PALETTE)]
              for key, count in title_rows]
    bar_figure([key for key, _ in title_rows], [count for _, count in title_rows], n,
               "学术出版AI政策的标题文种分布", output / "title_genres", colors=colors)
    # Keep a detailed version so small categories and zero-count categories are not
    # hidden by the publication-facing grouped chart.
    detailed_genres = genres.sort_values(["count", "genre"], ascending=[False, True], kind="stable")
    detailed_colors = [PALETTE[index % len(PALETTE)] for index in range(len(detailed_genres))]
    bar_figure(detailed_genres["genre"].tolist(), detailed_genres["count"].tolist(), n,
               "学术出版AI政策的标题文种（逐类）", output / "title_genres_detailed", colors=detailed_colors)
    level_order = ["未收录", "CSSCI(南大核心)", "北大核心+CSCD", "北大核心", "CSCD", "科技核心",
                   "SCI/SSCI收录", "其他收录", "北大核心+CSCD(联盟主体)"]
    level_map = dict(zip(levels["journal_level"], levels["count"]))
    level_counts = [int(level_map.get(label, 0)) for label in level_order]
    bar_figure(level_order, level_counts, n,
               "学术出版AI政策的发布主体等级", output / "journal_levels")
    combined_descriptive_figure(genres, levels, n, output / "title_genres_journal_levels_combined")
    bar_figure(years["year"].tolist(), years["count"].tolist(), n,
               "学术出版AI政策可识别发布/落款年份分布", output / "policy_years")
    for actor in ACTORS:
        ego_figure(edges, actor, output / ("network_" + actor.strip("【】")))
