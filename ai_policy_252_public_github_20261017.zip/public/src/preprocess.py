"""Prepare sentences only from the bundled, cleaned policy CSV."""
import re
from .io_utils import read_csv, write_csv, write_json, sha256, text_hash

SENTENCE_FIELDS = ["doc_id", "sentence_id", "title", "sentence", "sentence_sha256"]
REQUIRED_ID_FIELDS = {"record_id", "title"}


def validate_corpus_rows(rows, expected_records=None):
    """Validate the tabular contract before generating sentence records."""
    if not rows:
        raise ValueError("Corpus is empty")
    fields = set(rows[0])
    missing = REQUIRED_ID_FIELDS - fields
    if missing:
        raise ValueError("Corpus is missing required columns: " + ", ".join(sorted(missing)))
    if not ({"analysis_text", "text"} & fields):
        raise ValueError("Corpus must contain analysis_text or text")
    if expected_records is not None and len(rows) != expected_records:
        raise ValueError("Expected {} policy records, found {}".format(expected_records, len(rows)))
    ids = []
    for index, row in enumerate(rows, 1):
        record_id = (row.get("record_id") or "").strip()
        title = (row.get("title") or "").strip()
        if not record_id:
            raise ValueError("Blank record_id at corpus row {}".format(index))
        if not title:
            raise ValueError("Blank title at corpus row {} ({})".format(index, record_id))
        ids.append(record_id)
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate record_id in corpus")
    return rows


def split_sentences(text):
    for block in re.split(r"[\r\n]+", (text or "").replace("\t", " ")):
        for part in re.split(r"(?<=[。！？；!?;])", block):
            if part.strip():
                yield part.strip()


def prepare(corpus, output, expected_records=None):
    rows = read_csv(corpus)
    validate_corpus_rows(rows, expected_records=expected_records)
    sentences, empty = [], []
    for row in rows:
        text = row.get("analysis_text", row.get("text", ""))
        if not text.strip():
            empty.append({"record_id": row["record_id"], "title": row["title"], "reason": "empty_cleaned_text"})
        for index, sentence in enumerate(split_sentences(text)):
            sentences.append({"doc_id": row["record_id"],
                              "sentence_id": "{}_{}".format(row["record_id"], index),
                              "title": row["title"], "sentence": sentence,
                              "sentence_sha256": text_hash(sentence)})
    write_csv(output / "sentences.csv", sentences, SENTENCE_FIELDS)
    write_csv(output / "empty_texts.csv", empty, ["record_id", "title", "reason"])
    audit = {"corpus_sha256": sha256(corpus), "records": len(rows), "empty_records": len(empty),
             "records_with_sentences": len({row["doc_id"] for row in sentences}),
             "sentences": len(sentences), "unique_sentence_texts": len({row["sentence_sha256"] for row in sentences})}
    write_json(output / "preprocess_audit.json", audit)
    return sentences, audit
