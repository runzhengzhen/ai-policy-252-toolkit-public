"""Frozen, auditable predicate-to-VerbAtlas mapping; no LLM/API required."""
import json
import re
from collections import Counter, defaultdict
import pandas as pd
from .io_utils import ROOT, read_csv, write_csv, write_json

ACTORS = ["【作者】", "【期刊方】", "【AI工具】"]
AI = ["人工智能", "AI", "AIGC", "生成式", "大模型", "chatgpt", "语言模型", "智能工具", "工具", "生成-01", "生成"]
SELF = ["本刊", "编辑部", "本社", "本报", "本杂志", "期刊", "本规范", "我们", "我刊"]
AUTHOR = ["作者", "投稿人", "来稿", "投稿"]


def strip_sense(value):
    return re.sub(r"-\d+$", "", str(value))


def normalize_actor(value):
    if not isinstance(value, str):
        return None
    text = value.strip()
    if any(term.lower() in text.lower() for term in AI):
        return "【AI工具】"
    if any(term in text for term in SELF):
        return "【期刊方】"
    if any(term in text for term in AUTHOR):
        return "【作者】"
    return text


def clean_argument(value):
    if not isinstance(value, str):
        return None
    text = value.strip()
    if text in ("", "amr-unknown"):
        return None
    if text.startswith("【") and text.endswith("】"):
        return text
    text = text.split("|")[0].split(":")[0].strip()
    if re.search(r"-\d+$", text):
        return None
    if re.search(r"[a-zA-Z]", text) and not re.search(r"[一-鿿]", text):
        return None
    return text or None


def official_candidates():
    resource = ROOT / "resources/VerbAtlas-1.1.0/VerbAtlas-1.1.0"
    info = pd.read_csv(resource / "VA_frame_info.tsv", skiprows=1, sep="\t", header=None)
    id_to_label = dict(zip(info[0], info[1]))
    definitions = dict(zip(info[1], info[2]))
    candidates = defaultdict(dict)
    with (resource / "pb2va.tsv").open(encoding="utf-8") as stream:
        next(stream)
        for line in stream:
            pb, tail = line.split(">", 1)
            va_id = tail.split("\t", 1)[0].strip()
            if "." in pb and va_id in id_to_label:
                lemma = pb.rsplit(".", 1)[0]
                candidates[lemma].setdefault(id_to_label[va_id], {"sense": pb, "va_id": va_id})
    return candidates, definitions


def annotate_stance(row, annotations):
    label = annotations.get(row["predicate_va"], "N")
    negative = sum(row.get(field) == "-" for field in
                   ["predicate_pol", "parent_predicate_pol", ":ARG0_pol", ":ARG1_pol"])
    if negative % 2 and label in ("A", "B"):
        return "B" if label == "A" else "A"
    return label


def add_semantics(frame, sentences, mapping_path, output):
    candidates, definitions = official_candidates()
    seed_rows = read_csv(mapping_path)
    required = {"predicate", "lemma", "frame"}
    for row in seed_rows:
        missing = required - set(row)
        if missing:
            raise ValueError("Mapping is missing columns: " + ", ".join(sorted(missing)))
        if not row.get("predicate", "").strip():
            raise ValueError("Mapping contains a blank predicate")
    seed = {row["predicate"]: row for row in seed_rows}
    if len(seed) != len(seed_rows):
        raise ValueError("Duplicate predicate in frozen mapping")
    sentence_text = {row["sentence_id"]: row["sentence"] for row in sentences}
    chinese = frame[frame["predicate_pb"].astype(str).str.contains(r"[一-鿿]", regex=True)].copy()
    chinese["predicate"] = chinese["predicate_pb"].apply(strip_sense)
    current_counts = Counter(chinese["predicate"])
    decisions, review = [], []
    for predicate, freq in sorted(current_counts.items(), key=lambda item: (-item[1], item[0])):
        original = seed.get(predicate, {})
        lemma = original.get("lemma", "")
        label = original.get("frame", "").strip()
        if label and label not in candidates.get(lemma, {}):
            raise ValueError("Non-official candidate: {} -> {} -> {}".format(predicate, lemma, label))
        method = original.get("method", "unmapped_new_predicate")
        row = {"predicate": predicate, "lemma": lemma, "frame": label, "freq": freq,
               "confidence": original.get("confidence", ""), "method": method,
               "mapping_origin": original.get("mapping_origin", "frozen_prior_codex_decision" if original else "unresolved"),
               "review_note": original.get("review_note", "")}
        for field in ["crosscheck_freq", "crosscheck_main_frame", "crosscheck_frame",
                      "crosscheck_confidence", "crosscheck_agree", "crosscheck_layer"]:
            row[field] = original.get(field, "")
        decisions.append(row)
        if predicate not in seed:
            subset = chinese[chinese["predicate"] == predicate]
            examples = list(dict.fromkeys(sentence_text.get(sid, "") for sid in subset["sentence_id"]))[:3]
            review.append({"predicate": predicate, "freq": freq, "examples": examples})
    write_csv(output / "predicate_mapping.csv", decisions,
              ["predicate", "lemma", "frame", "freq", "confidence", "method", "mapping_origin", "review_note",
               "crosscheck_freq", "crosscheck_main_frame", "crosscheck_frame", "crosscheck_confidence",
               "crosscheck_agree", "crosscheck_layer"])
    write_json(output / "predicates_to_review.json", review)
    write_json(output / "official_lemma_candidates.json", candidates)
    mapping = {row["predicate"]: row["frame"] for row in decisions if row["frame"]}
    result = frame.copy()
    result["predicate_va"] = result["predicate_pb"].apply(lambda value: mapping.get(strip_sense(value), ""))
    result["parent_predicate_va"] = result["parent_predicate_pb"].apply(lambda value: mapping.get(strip_sense(value), ""))
    for role in [":ARG0", ":ARG1", ":ARG2"]:
        result[role + "_n"] = result[role].apply(normalize_actor).apply(clean_argument)
        result[role + "_c"] = result[role].apply(clean_argument)
    result["frame_mapped"] = result["predicate_va"].ne("")
    annotations = pd.read_csv(ROOT / "resources/annotation/VA_frame_info_annotation_v3.csv")
    annotations = dict(zip(annotations["VA_LABEL"], annotations["ANNOTATION"]))
    result["verb_annotation"] = result.apply(lambda row: annotate_stance(row, annotations), axis=1)
    result.to_csv(output / "va_events.csv", index=False, encoding="utf-8-sig", lineterminator="\n")
    audit = {"chinese_predicates": len(current_counts), "mapped_predicates": len(mapping),
             "unmapped_predicates": len(current_counts) - len(mapping),
             "unresolved_new_predicates": len(review), "event_rows": len(result),
             "mapped_event_rows": int(result["frame_mapped"].sum()),
             "event_frame_coverage": float(result["frame_mapped"].mean()),
             "mapping_methods": dict(Counter(row["method"] for row in decisions)),
             "stance_labels": {key: int(value) for key, value in result["verb_annotation"].value_counts().items()},
             "N_includes_unmapped_events": True, "no_external_API_called": True}
    write_json(output / "va_audit.json", audit)
    return result, audit
