"""Chinese HanLP MRP -> PENMAN adapter, including polarity and multiple roots."""
import penman
from penman.graph import Graph


def safe_concept(label):
    if not label:
        return "amr-unknown"
    value = str(label)
    for char in ['(', ')', '/', ':', '"', "'", ' ', '\t', '\n', '~']:
        value = value.replace(char, "_")
    return value.strip("_") or "amr-unknown"


def mrp_to_penman_string(mrp, tokens):
    if not mrp.get("edges"):
        return None
    labels = {node["id"]: node.get("label", "") for node in mrp["nodes"]}
    polarity_nodes, polarity_sources = set(), []
    for edge in mrp["edges"]:
        if edge["label"].lower() == "polarity" and labels.get(edge["target"]) == "-":
            polarity_nodes.add(edge["target"])
            polarity_sources.append(edge["source"])
    node_ids = [node["id"] for node in mrp["nodes"] if node["id"] not in polarity_nodes]
    edges = [edge for edge in mrp["edges"] if not (
        edge["target"] in polarity_nodes and edge["label"].lower() == "polarity")]
    children = {node: [] for node in node_ids}
    indegree = {node: 0 for node in node_ids}
    for edge in edges:
        children.setdefault(edge["source"], []).append(edge["target"])
        indegree[edge["target"]] = indegree.get(edge["target"], 0) + 1
    top = (mrp["tops"][0] if mrp.get("tops") and mrp["tops"][0] in node_ids
           else (node_ids[0] if node_ids else None))
    if top is None:
        return None

    def reachable(root):
        seen, pending = set(), [root]
        while pending:
            current = pending.pop()
            if current not in seen:
                seen.add(current)
                pending.extend(children.get(current, []))
        return seen

    reached, extra = reachable(top), []
    while any(node not in reached for node in node_ids):
        remaining = [node for node in node_ids if node not in reached]
        root = min(remaining, key=lambda node: (indegree.get(node, 0), node))
        extra.append(root)
        reached.update(reachable(root))
    var = lambda node: "x{}".format(node)
    triples = [(var(node["id"]), ":instance", safe_concept(node.get("label")))
               for node in mrp["nodes"] if node["id"] not in polarity_nodes]
    for edge in edges:
        role = edge["label"]
        role = role.upper() if role.lower().startswith("arg") else role
        triples.append((var(edge["source"]), ":" + role, var(edge["target"])))
    triples.extend((var(node), ":polarity", "-") for node in polarity_sources)
    graph_top = var(top)
    if extra:
        graph_top = "xroot"
        triples.append((graph_top, ":instance", "multi-sentence"))
        triples.extend((graph_top, ":snt{}".format(index), var(node))
                       for index, node in enumerate([top] + extra, 1))
    body = penman.encode(Graph(triples, top=graph_top))
    # Placeholder alignments are used only for upstream metadata compatibility.
    alignments = " ".join("{}~0".format(var(node)) for node in node_ids)
    return "# ::tok {}\n# ::alignments {}\n{}".format(" ".join(tokens), alignments, body)
