"""Deterministic descriptive tables, TF-IDF and directed narrative networks."""
from collections import Counter
import json
import re
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfTransformer
from .io_utils import ROOT, read_csv, write_csv, write_json
from .semantics import ACTORS, strip_sense, clean_argument

# Publication-form terms are checked from the most specific/explicit form to
# the more general residual forms.  “规范” is handled as a suffix/form phrase
# after the established forms: a title such as “规范公告” remains “公告”,
# while a title ending only in “使用规范” is no longer mislabeled as
# unclassifiable.  This also avoids treating an incidental occurrence such as
# “恪守学术规范” inside an accidentally extracted body sentence as a title
# genre.
TITLE_PRIORITY = ["声明", "启事", "规定", "公告", "说明", "通知", "办法", "倡议", "提示",
                  "须知", "指南", "要求", "承诺", "告知书", "建议", "政策", "立场", "提醒"]
GOAL_FRAMES = ["OBLIGE_FORCE", "REQUIRE_NEED_WANT_HOPE"]
GENERIC = ["这", "它", "那", "一些", "某", "等", "thing"]


def save_table(frame, path):
    frame.to_csv(path, index=False, encoding="utf-8-sig", lineterminator="\n", float_format="%.12g")


def count_table(values, label_name="label"):
    counts = Counter(value for value in values if isinstance(value, str) and value)
    return pd.DataFrame([{label_name: key, "count": count}
                         for key, count in sorted(counts.items(), key=lambda item: (-item[1], item[0]))],
                        columns=[label_name, "count"])


def title_genre(title):
    text = title or ""
    # The recovered page title “关于在论文写作中使用AI工具的说明提示” uses
    # “提示” as its operative publication form; keep the compound wording from
    # being silently classified by the earlier “说明” match.
    if "说明提示" in text:
        return "提示"
    found = next((term for term in TITLE_PRIORITY if term in text), None)
    if found:
        return found
    # Only accept “规范” when it behaves like a title form at the end of the
    # extracted title, or in the common incomplete-title phrase “规范使用”.
    if re.search(r"(?:规范|规范使用)\s*[》】）)』」］\]}。，；:：,，！!？?]*$", text):
        return "规范"
    return "其他/无法判定"


def goals(frame, actor):
    direct = frame[(frame[":ARG0_n"] == actor) & frame["predicate_va"].isin(GOAL_FRAMES)
                   & frame["predicate_pol"].eq("+")].copy()
    nested = frame[(frame[":ARG0_n"] == actor) & frame["parent_predicate_va"].isin(GOAL_FRAMES)
                   & frame["parent_predicate_pol"].eq("+")].copy()
    nested = nested[~nested["sentence_id"].isin(set(direct["sentence_id"]))]
    direct["goal_type"] = "direct"
    nested["goal_type"] = "framed"
    return pd.concat([direct, nested], ignore_index=True)


def tfidf_table(frame, goal_only=False):
    vectors = {}
    for actor in ACTORS:
        selected = goals(frame, actor) if goal_only else frame[frame[":ARG0_n"] == actor]
        targets = selected[":ARG1"].apply(clean_argument).dropna()
        targets = targets[~targets.isin(GENERIC)]
        vectors[actor] = targets.value_counts()
    counts = pd.DataFrame(vectors).fillna(0)
    counts = counts[counts.sum(axis=1) >= 2].sort_index()
    columns = ["actor", "term", "count", "tfidf"]
    if counts.empty:
        return pd.DataFrame(columns=columns)
    weights = TfidfTransformer().fit_transform(counts.to_numpy().T).toarray()
    rows = []
    for actor_index, actor in enumerate(ACTORS):
        order = sorted(range(len(counts)), key=lambda index: (-weights[actor_index, index], str(counts.index[index])))
        for index in order:
            if weights[actor_index, index] > 0:
                rows.append({"actor": actor, "term": counts.index[index],
                             "count": int(counts.iloc[index][actor]), "tfidf": float(weights[actor_index, index])})
    return pd.DataFrame(rows, columns=columns)


def narrative_edges(frame):
    selected = frame.copy()
    selected["source"] = selected[":ARG0_n"]
    selected["target"] = selected[":ARG1_c"]
    selected = selected[selected["source"].notna() & selected["target"].notna()]
    removed = GENERIC + ["内容", "情况", "信息"]
    selected = selected[~selected["source"].isin(removed) & ~selected["target"].isin(removed)]
    counts = selected.groupby(["source", "target", "verb_annotation"], sort=True).size().unstack(fill_value=0)
    for label in ["A", "B", "N"]:
        if label not in counts:
            counts[label] = 0
    counts = counts.reset_index()
    counts["weight"] = counts["A"] + counts["B"]
    counts = counts[counts["weight"] > 0].copy()
    counts["score"] = (counts["B"] - counts["A"]) / counts["weight"]
    return counts[["source", "target", "A", "B", "N", "weight", "score"]].sort_values(
        ["weight", "source", "target"], ascending=[False, True, True], kind="stable").reset_index(drop=True)


def run_analysis(frame, sentences, corpus_path, audits, output):
    tables = output / "tables"
    figures = output / "figures"
    tables.mkdir(parents=True, exist_ok=True)
    figures.mkdir(parents=True, exist_ok=True)
    corpus = read_csv(corpus_path)
    n = len(corpus)
    corpus_ids = {row.get("record_id") for row in corpus}
    sentence_ids = {row.get("sentence_id") for row in sentences}
    if audits["preprocess"]["records"] != n:
        raise ValueError("Preprocess audit record count does not match corpus")
    if any(row.get("doc_id") not in corpus_ids for row in sentences):
        raise ValueError("Sentence table contains a document outside the corpus")
    frame = frame.copy()
    frame["action"] = frame["predicate_pb"].apply(strip_sense)
    frame["is_chinese_action"] = frame["action"].str.contains(r"[一-鿿]", regex=True)
    frame["doc_id"] = frame["sentence_id"].str.rsplit("_", n=1).str[0]
    if any(value not in sentence_ids for value in frame["sentence_id"]):
        raise ValueError("Event table contains a sentence outside the prepared sentence table")
    actions = frame[frame["is_chinese_action"]]
    save_table(count_table(actions["action"], "action"), tables / "amr_actions.csv")
    save_table(count_table(frame.loc[~frame["is_chinese_action"], "action"], "function_label"), tables / "amr_function_labels.csv")
    save_table(count_table(frame[":ARG0_n"], "actor"), tables / "amr_agents.csv")
    save_table(count_table(frame[":ARG1_n"], "target"), tables / "amr_patients.csv")
    hierarchy = frame.groupby("hierarchy_level").size().rename("count").reset_index()
    save_table(hierarchy, tables / "amr_hierarchy.csv")
    pairs = Counter()
    for row in frame.itertuples(index=False):
        parent = getattr(row, "parent_predicate_pb")
        if isinstance(parent, str):
            for item in parent.split("|"):
                if item.strip():
                    pairs[(strip_sense(item.strip()), getattr(row, "action"))] += 1
    pair_rows = [{"parent": key[0], "child": key[1], "count": count}
                 for key, count in sorted(pairs.items(), key=lambda item: (-item[1], item[0]))]
    save_table(pd.DataFrame(pair_rows, columns=["parent", "child", "count"]), tables / "amr_parent_child.csv")
    negative = actions[actions["predicate_pol"].eq("-")]
    save_table(count_table(negative["action"], "action"), tables / "amr_negated_actions.csv")
    triples = actions.groupby([":ARG0_n", "action", ":ARG1_n"], sort=True).size().rename("count").reset_index()
    triples.columns = ["actor", "action", "target", "count"]
    save_table(triples.sort_values(["count", "actor", "action", "target"], ascending=[False, True, True, True]),
               tables / "amr_actor_action_target.csv")
    save_table(count_table(frame.loc[frame["frame_mapped"], "predicate_va"], "frame"), tables / "va_frames.csv")
    save_table(tfidf_table(frame), tables / "va_patient_tfidf.csv")
    save_table(tfidf_table(frame, goal_only=True), tables / "va_goal_tfidf.csv")
    goal_rows = []
    for actor in ACTORS:
        selected = goals(frame, actor)
        for _, row in selected.iterrows():
            goal_rows.append({"actor": actor, "sentence_id": row["sentence_id"], "event_id": row["event_id"],
                              "predicate": row["predicate_pb"], "frame": row["predicate_va"],
                              "parent_frame": row["parent_predicate_va"], "goal_type": row["goal_type"],
                              "target": clean_argument(row[":ARG1"]) or ""})
    write_csv(tables / "va_goal_instances.csv", goal_rows,
              ["actor", "sentence_id", "event_id", "predicate", "frame", "parent_frame", "goal_type", "target"])
    edges = narrative_edges(frame)
    save_table(edges, tables / "va_network_edges.csv")
    for actor in ACTORS:
        ego = edges[(edges["source"].eq(actor) | edges["target"].eq(actor)) & edges["source"].ne(edges["target"])]
        save_table(ego, tables / ("va_ego_" + actor.strip("【】") + ".csv"))

    genres = count_table([title_genre(row["title"]) for row in corpus], "genre")
    genres["share"] = genres["count"] / n
    save_table(genres, tables / "title_genres.csv")
    levels = count_table([row.get("journal_level") or "未提供" for row in corpus], "journal_level")
    levels["share"] = levels["count"] / n
    save_table(levels, tables / "journal_levels.csv")
    # The primary year table uses the conservative publication-oriented field.
    # Effective dates and submission/deadline dates remain visible in the
    # corpus but are not silently presented as publication years.
    release_year_values = [row.get("policy_release_year") if re.fullmatch(r"\d{4}", row.get("policy_release_year", ""))
                           else "未确定或非发布时间" for row in corpus]
    years = count_table(release_year_values, "year").sort_values("year", kind="stable")
    years["share"] = years["count"] / n
    save_table(years, tables / "policy_years.csv")
    temporal_year_values = [row.get("policy_year") if re.fullmatch(r"\d{4}", row.get("policy_year", "")) else "未确定年份"
                            for row in corpus]
    temporal_years = count_table(temporal_year_values, "year").sort_values("year", kind="stable")
    temporal_years["share"] = temporal_years["count"] / n
    save_table(temporal_years, tables / "policy_temporal_signals.csv")
    temporal_roles = count_table([row.get("policy_date_temporal_role") or "未标注" for row in corpus], "temporal_role")
    temporal_roles["share"] = temporal_roles["count"] / n
    save_table(temporal_roles, tables / "policy_date_quality.csv")
    event_counts = frame.groupby("doc_id").size()
    sentence_counts = Counter(row["doc_id"] for row in sentences)
    per_policy = [{"record_id": row["record_id"], "title": row["title"],
                   "sentences": sentence_counts.get(row["record_id"], 0),
                   "event_rows": int(event_counts.get(row["record_id"], 0)),
                   "policy_date": row.get("policy_date", ""), "journal_level": row.get("journal_level", "")}
                  for row in corpus]
    write_csv(tables / "per_policy_coverage.csv", per_policy,
              ["record_id", "title", "sentences", "event_rows", "policy_date", "journal_level"])
    sentence_map = {row["sentence_id"]: row["sentence"] for row in sentences}
    instances = frame[["event_id", "sentence_id", "doc_id", "predicate_pb", "predicate_va", "predicate_pol",
                       "hierarchy_level", "parent_predicate_pb", ":ARG0_n", ":ARG1_n", "frame_mapped", "verb_annotation"]].copy()
    instances["sentence"] = instances["sentence_id"].map(sentence_map)
    save_table(instances, tables / "event_instances_with_text.csv")

    # Prior independent-route labels travel with the mapping table as audit columns,
    # not as a second data file and not as a new human gold standard.
    current_mapping_rows = read_csv(output / "predicate_mapping.csv")
    fixed_check = [row for row in current_mapping_rows if row.get("crosscheck_frame")]
    current_mapping = {row["predicate"]: row for row in current_mapping_rows}
    check_rows = []
    for row in fixed_check:
        current = current_mapping.get(row["predicate"])
        check_rows.append({"predicate": row["predicate"], "active_in_current_run": bool(current),
                           "current_freq": int(current["freq"]) if current else 0,
                           "current_frame": current["frame"] if current else "",
                           "frozen_crosscheck_frame": row["crosscheck_frame"],
                           "agree": bool(current) and current["frame"] == row["crosscheck_frame"]})
    write_csv(tables / "mapping_crosscheck_recalculated.csv", check_rows,
              ["predicate", "active_in_current_run", "current_freq", "current_frame", "frozen_crosscheck_frame", "agree"])
    active_check = [row for row in check_rows if row["active_in_current_run"]]
    frequency_total = sum(row["current_freq"] for row in active_check)
    summary = {
        "corpus": audits["preprocess"], "amr": audits["events"], "va": audits["va"],
        "chinese_action_rows": int(len(actions)), "negated_event_rows": int(frame["predicate_pol"].eq("-").sum()),
        "network_edges_A_B_only": int(len(edges)),
        "network_nodes_A_B_only": len(set(edges["source"]) | set(edges["target"])),
        "title_statement_and_notice": {"count": int(genres[genres["genre"].isin(["声明", "启事"])]["count"].sum()),
                                       "denominator": n},
        "policy_dates": {
            "publication_or_issue_date_signal": int(sum(bool(row.get("policy_release_year")) for row in corpus)),
            "no_publication_year_or_nonpublication_date": int(sum(not bool(row.get("policy_release_year")) for row in corpus)),
            "release_year_distribution": years.to_dict(orient="records"),
            "temporal_signal_distribution": temporal_years.to_dict(orient="records"),
            "quality_distribution": temporal_roles.to_dict(orient="records"),
        },
        "goal_rows_by_actor": dict(Counter(row["actor"] for row in goal_rows)),
        "frozen_crosscheck": {"active_items": len(active_check),
                              "agreement": sum(row["agree"] for row in active_check) / len(active_check) if active_check else None,
                              "frequency_weighted_agreement": sum(row["current_freq"] for row in active_check if row["agree"]) / frequency_total if frequency_total else None,
                              "scope": "historical_model_route_labels_reweighted_to_current_predicates_not_human_accuracy"},
    }
    write_json(output / "summary.json", summary)
    from .figures import draw_all
    draw_all(genres, levels, years, edges, figures, n)
    report = ["# 252条政策分析结果", "", "## 数据覆盖", "",
              "- 政策清单：{}条；有可切分正文：{}条；空正文：{}条。".format(
                  n, audits["preprocess"]["records_with_sentences"], audits["preprocess"]["empty_records"]),
              "- 切句：{}句；事件表：{}行；独立事件编号：{}个。".format(
                  len(sentences), audits["events"]["event_rows"], audits["events"]["unique_event_ids"]),
              "- 事件覆盖：{}句、{}条记录；事件子图抽取异常：{}句。".format(
                  audits["events"]["sentences_with_events"], audits["events"]["records_with_events"],
                  audits["events"]["graph_extraction_failures"]),
              "- VA框架覆盖：{}/{}事件表行（{:.1%}）；覆盖率不是准确率。".format(
                  audits["va"]["mapped_event_rows"], len(frame), audits["va"]["event_frame_coverage"]),
              "", "## 结果文件", "",
              "- tables/：动作、主体、受事、层级、否定、父子谓词、TF-IDF、目标实例与网络边表。",
              "- figures/：标题文种（分组版与逐类版）、发布主体等级、可识别发布/落款年份及三方主体网络（PNG和SVG）。",
              "- tables/event_instances_with_text.csv：带原句的事件实例，可按事件编号追溯。",
              "", "## 解释边界", "",
              "- 事件表行数与独立事件编号数分别报告，避免把论元展开行误作互不相同的事件。",
              "- 词表归并保留既有研究规则；同一谓词共享一个冻结框架，未覆盖项不猜测框架。",
              "- A/B/N来自框架及否定规则；N还包含未映射事件，不能全部解释为中立态度。",
              "- 网络得分为(B-A)/(B+A)，N不进分母；网络图仅展示权重至少为2的最强35条相关边。",
              "- 日期角色、发布年份与期刊等级是随包冻结的研究元数据，本次不重新查询外部数据库；policy_temporal_signals.csv保留综合时间信号供审计。",
              "- 当前结果由252条有效语料重新生成，验收以当前输入和当前统计为准。", ""]
    (output / "REPORT.md").write_text("\n".join(report), encoding="utf-8")
    return summary
