# 数据和输出字段

## data/policies.csv

- `record_id`：政策记录编号，是连接全部结果的主键。
- `title`：目前使用的政策题名。
- `text`、`analysis_text`：清理后正文；本包的分析以analysis_text为准。
- `policy_date`、`policy_year`、`policy_month`：冻结的日期信号。日期可以是页面发布日期、正文落款日期、施行/生效日期或投稿适用/截止日期，具体角色见后续字段。
- `policy_date_precision`、`policy_date_type`、`policy_date_confidence`、`policy_date_evidence`：精度、类型、核验标记与逐条日期证据，均随包冻结。
- `policy_date_source_field`：日期证据来自清理正文`text`、原始采集文本`raw_text`，或为空。
- `policy_date_temporal_role`：时间角色。发布/来源页/落款日期用于发布年份统计；施行/生效日期、投稿适用日期和投稿截止日期不直接当作发布时间；无可识别年份单独保留。
- `policy_release_year`：保守的发布/落款年份统计字段。只有具有发布/来源页/落款日期线索的记录填写；非发布时间日期和未识别日期留空。
- `representative_subject`、`journal_level`、`all_rank_tags`：已有发布主体与收录编码。
- `unit_rule`：以政策文本为单位的编码说明。

主语料表已去除来源分组、采集状态、清洗备注和URL等采集字段；省略项列表在`corpus_provenance.json`。这不改变正文和`analysis_text`列的内容。

原始采集文本和可用的来源文件现另存于`sources/`；`sources/source_index.csv`以`record_id`为主键，记录252条政策的包内来源文件、网页快照、附件、原始文本路径和文件哈希，但不保留外部URL列。不要把来源材料中的原始文本直接替代当前分析输入`data/policies.csv`。

## sentences.csv与AMR预测

- `doc_id`对应record_id。
- `sentence_id`为政策编号与句序的组合。
- `sentence`为实际送入模型的字符串。
- `sentence_sha256`为上述字符串UTF-8字节的SHA-256。
- `amr_string`为PENMAN文本，失败或无边为`<NAN>`。

`from-amr`输入必须包含`doc_id,sentence_id,sentence_sha256,amr_string`四列，并与当前切句逐行对应。仅文件名相同不能绕过正文内容检查。

## amr_events.csv与va_events.csv

- `event_id`：上游事件编号，多论元展开时可能重复。
- `predicate_pb`：原始AMR谓词；编号后缀不等于本研究重新标注的中文词义。
- `predicate_pol`：谓词极性，`+`或`-`。
- `hierarchy_level`：图中谓词嵌套层级。
- `parent_predicate_pb`、`parent_predicate_pol`、`parent_id`：父谓词及相关信息；多值可能以`|`连接。
- `:ARG0`至`:ARG4`：原始语义角色；`_pol`为极性，`_adj`及`_nid`等为上游保留字段。
- `predicate_va`、`parent_predicate_va`：冻结映射产生的框架。
- `:ARG0_n`等：归一化并清理后的论元；`:ARG0_c`等为只作轻清理的论元。
- `frame_mapped`：该行事件是否有非空框架。
- `verb_annotation`：A、B、N标签。N包括未映射项，不等于全部中立。

## mapping与审计

- `predicate_mapping.csv`：每个中文谓词一行；同一词共享框架。`mapping_origin`与`review_note`说明沿用或补充判断的来源。
- `new_predicate_review.json`：本轮新增词项的原句与处理备注，包括保留空值的项目。
- `predicates_to_review.json`：运行输入出现尚未纳入冻结表的谓词时生成的待核查列表。
- `mapping_crosscheck_recalculated.csv`：以历史冻结的独立流程标签比较本次映射，并重算本次词频；不是新的人工作业结果。

## 主要结果

- `per_policy_coverage.csv`：252条有效记录逐条覆盖。
- `event_instances_with_text.csv`：事件与原句对应，可查错。
- `amr_*.csv`：动作、主体、受事、层级、否定、父子谓词及三元关系。
- `va_*.csv`：语义框架、主体对象TF-IDF、目标TF-IDF、目标实例和网络边表。
- `title_genres.csv`：题名文种，使用代码中的固定优先级并识别标题末端的“规范/规范使用”形式，每份政策只归一类；题名字段曾被抓成刊名或正文片段的26条已回到原始DOCX、网页标题或正文逐条恢复，依据见`docs/title_genre_audit.csv`。投稿须知页面中的AI条款按“须知”计入；S010原题名“说明提示”按标题末端的实际发布形式计为“提示”。
- `journal_levels.csv`、`policy_years.csv`：以252条为分母的主要统计。`policy_years.csv`使用`policy_release_year`，将未确定年份与非发布时间日期合并显示。
- `policy_temporal_signals.csv`：审计表，保留原先综合`policy_year`信号的年份分布，其中包含施行/生效日期和投稿适用/截止日期。
- `policy_date_quality.csv`：时间角色的汇总；逐条日期证据已直接保留在`data/policies.csv`的`policy_date_*`字段中。
