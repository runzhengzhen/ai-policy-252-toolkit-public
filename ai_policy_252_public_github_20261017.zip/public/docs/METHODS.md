# 技术流程与统计定义

## 输入和切句

唯一正文来源为`data/policies.csv`的`analysis_text`列；不存在该列时才使用`text`。当前包只保留252条有效政策，所有记录均有非空分析正文。按换行以及句号、问号、感叹号、分号切分，编号为`政策编号_句序号`，句序从0开始。不以旧版语料或旧事件表作为当前输入。

## 中文AMR

中文分词模型为HanLP `COARSE_ELECTRA_SMALL_ZH`，AMR模型为`MRP2020_AMR_ZHO_MENGZI_BASE`。模型冻结，不重新训练。推理随机种子42、批大小16，同文本句子共享一次推理。无边或解析异常保存为`<NAN>`。异常日志与无事件图分别保存。

MRP转换为PENMAN时，arg0等统一为大写ARG角色；指向独立负号节点的polarity边改为`:polarity -`属性；非连通分量由虚拟multi-sentence根连接。词元对齐为上游代码兼容占位，不应据此宣称精确的词元—概念对齐。

## 事件表

源于Pournaki与Willaert配套soteu代码的图流程：PENMAN图→谓词及最近父谓词→事件子图→参与者子图→表格。移植代码保留原研究图算法，增加已有边界保护，资源路径改为代码文件相对路径。每个事件可能因多个论元而展开多行，因此同时报告事件表行数和独立事件编号数。

ARG0、ARG1是随谓词变化的语义角色。常见行动句中，ARG0近似行动发出者，ARG1近似作用对象；二者不能机械等同语法主语、宾语或现实中的责任主体。

作者、期刊方与AI工具归并词表见`src/semantics.py`。该词表保留原项目的宽泛匹配规则，例如包含“工具”的标签可归入AI工具。此为统计规则，不是人工实体识别金标准。原始论元仍保留，新增`_n`为归一化值，`_c`为轻度清理值。

中文行动统计剔除纯英文功能标签。层级、父子谓词、条件与否定描述句内语义关系，不自动代表程序的时间顺序或真实因果关系。

## VerbAtlas映射

使用VerbAtlas 1.1.0的官方`pb2va.tsv`与`VA_frame_info.tsv`建立英文词元候选表。`data/predicate_mapping.csv`存储固定中文谓词、英文词元、框架、来源与处理备注。所有非空框架必须在对应词元的官方候选中，否则运行报错。

去除词义编号后，同一中文谓词在各句中共享同一框架。不是逐事件重新消歧，也没有把全部AMR论元转换为VerbAtlas的完整角色集。无法可靠解释的解析片段、虚词或异常标签保留空框架，原AMR事件不删除。

框架覆盖率＝获得非空框架的事件表行数/全部事件表行数。它不是准确率。框架置信度沿用历史模型自评或保留空值，不作为人工准确度。

## TF-IDF与目标

以作者、期刊方、AI工具三类主体对应的事件集合为三个文档，以ARG1的轻度清理值为词项，构建计数矩阵。保留全体主体总频次至少为2的词项，使用scikit-learn `TfidfTransformer`的默认平滑IDF与L2归一化。输出数值型长表，未把词项和分数拼接为字符串。

目标筛选使用`OBLIGE_FORCE`与`REQUIRE_NEED_WANT_HOPE`两类框架，分别提取主体直接参与的正极性需求事件，以及被正极性需求父谓词支配的事件；如同句已有直接事件，则不重复计入其嵌套事件。这里的目标是文本要求或需求，不是真实心理动机。

## 标签和网络

框架A/B/N标签来自soteu配套资源`VA_frame_info_annotation_v3.csv`。A为冲突或施压、B为支持、N为其余；未映射事件同样返回N。按事件谓词、父谓词、ARG0与ARG1的负极性标记进行奇偶次翻转，A与B互换，N不变。

网络采用ARG0归一化值作为source、ARG1轻度清理值作为target，排除泛化词，按主体对汇总A、B、N。只保留A+B大于0的边，边权为A+B，得分为(B-A)/(B+A)。N不进入得分分母，这与原论文正文包含中立项的公式不同，不能写成公式完全相同。

三个主体网络图只展示与主体相邻、权重至少为2的最强35条边，布局随机种子42，长于12字的标签缩略显示。完整关系保存在CSV，制图截取不改变统计结果。图形不能直接证明政策态度、约束力度或实际效果。

## 方法来源

- Pournaki, A., & Willaert, T. (2025). Extracting narrative signals from public discourse: a network-based approach. Humanities and Social Sciences Communications, 12, 1774. https://doi.org/10.1057/s41599-025-06017-x
- 上述论文原本已使用VerbAtlas分析目标和主体关系。本项目扩展为中文AMR及中文谓词英译、候选消歧，不是首次将VA接入该框架。
- Di Fabio, A., Conia, S., & Navigli, R. (2019). VerbAtlas: a Novel Large-Scale Verbal Semantic Resource and Its Application to Semantic Role Labeling. https://aclanthology.org/D19-1058/
- HanLP中文AMR模型说明：https://hanlp.hankcs.com/docs/api/hanlp/pretrained/amr.html
