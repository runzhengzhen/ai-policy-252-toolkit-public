#!/usr/bin/env python3
"""Standalone entry point. All defaults resolve from this file, not the CWD."""
import argparse
import importlib.metadata
import json
import os
from pathlib import Path
import sys
from src.io_utils import ROOT, read_csv, write_csv, write_json, sha256
from src.preprocess import prepare

MUTABLE_ROOTS = {"outputs", ".models"}
EPHEMERAL_PARTS = {"__pycache__"}


def _relative_files():
    files = set()
    for path in ROOT.rglob("*"):
        if not path.is_file() or path.name == "PACKAGE_MANIFEST.json":
            continue
        relative = path.relative_to(ROOT)
        if relative.parts and relative.parts[0] in MUTABLE_ROOTS:
            continue
        if any(part in EPHEMERAL_PARTS for part in relative.parts) or path.suffix == ".pyc" or path.name == ".DS_Store":
            continue
        files.add(relative.as_posix())
    return files


def validate_cached_predictions(sentences, predictions):
    if len(sentences) != len(predictions):
        raise ValueError("Cached AMR row count differs from current sentences; run full mode")
    required = {"sentence_id", "doc_id", "sentence_sha256", "amr_string"}
    for row in predictions:
        missing = required - set(row)
        if missing:
            raise ValueError("AMR cache is missing columns: " + ", ".join(sorted(missing)))
    cache = {row["sentence_id"]: row for row in predictions}
    if len(cache) != len(predictions):
        raise ValueError("Duplicate sentence_id in AMR cache")
    ordered = []
    for row in sentences:
        prediction = cache.get(row["sentence_id"])
        if not prediction or prediction.get("sentence_sha256") != row["sentence_sha256"] or prediction.get("doc_id") != row["doc_id"]:
            raise ValueError("AMR cache does not match current input: " + row["sentence_id"])
        ordered.append(prediction)
    return ordered


def verify_package():
    manifest = ROOT / "PACKAGE_MANIFEST.json"
    if not manifest.is_file():
        raise FileNotFoundError("Release manifest not found")
    data = json.loads(manifest.read_text(encoding="utf-8"))
    expected_files = set(data.get("sha256", {}))
    actual_files = _relative_files()
    if expected_files != actual_files:
        missing = sorted(expected_files - actual_files)
        extra = sorted(actual_files - expected_files)
        details = []
        if missing:
            details.append("missing=" + ", ".join(missing[:10]))
        if extra:
            details.append("unlisted=" + ", ".join(extra[:10]))
        raise RuntimeError("Package file inventory mismatch: " + "; ".join(details))
    if data.get("file_count_without_manifest") != len(expected_files):
        raise RuntimeError("Manifest file count does not match its hash table")
    failures = []
    for relative, expected in data["sha256"].items():
        path = ROOT / relative
        if not path.is_file() or sha256(path) != expected:
            failures.append(relative)
    if failures:
        raise RuntimeError("Package integrity check failed: " + ", ".join(failures))
    print("Package integrity: PASS ({} files)".format(len(data["sha256"])), flush=True)


def verify_corpus_contract():
    rows = read_csv(ROOT / "data/policies.csv")
    if len(rows) != 252:
        raise RuntimeError("Bundled corpus must contain 252 records, found {}".format(len(rows)))
    ids = [row.get("record_id", "") for row in rows]
    if len(ids) != len(set(ids)) or any(not item for item in ids):
        raise RuntimeError("Bundled corpus has missing or duplicate record_id values")
    if any(not (row.get("analysis_text") or "").strip() for row in rows):
        raise RuntimeError("Bundled corpus contains blank analysis_text")
    source_index = read_csv(ROOT / "sources/source_index.csv")
    source_ids = {row.get("record_id") for row in source_index}
    if len(source_index) != 252 or source_ids != set(ids):
        raise RuntimeError("Source index is not exactly aligned to the 252-record corpus")
    print("Corpus contract: PASS (252 policies, 252 source records)", flush=True)


def verify_results(summary):
    path = ROOT / "expected/summary.json"
    expected = json.loads(path.read_text(encoding="utf-8"))
    failures = []
    def compare(expected_value, actual_value, location):
        if isinstance(expected_value, dict):
            if not isinstance(actual_value, dict):
                failures.append("{}: {} != {}".format(location, actual_value, expected_value))
                return
            for key, value in expected_value.items():
                compare(value, actual_value.get(key), "{}.{}".format(location, key))
        elif actual_value != expected_value:
            failures.append("{}: {} != {}".format(location, actual_value, expected_value))
    for section, fields in expected.items():
        compare(fields, summary.get(section), section)
    if failures:
        raise RuntimeError("Benchmark mismatch:\n" + "\n".join(failures))
    print("Reference result checks: PASS", flush=True)


def doctor():
    print("Python:", sys.version.split()[0])
    print("Package root discovered relative to run.py:", ROOT.name)
    for name in ["numpy", "pandas", "igraph", "penman", "scikit-learn", "matplotlib", "networkx", "hanlp", "torch"]:
        try:
            version = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            version = "not installed (required only for fresh inference)" if name in ["hanlp", "torch"] else "MISSING"
        print("{}: {}".format(name, version))
    print("Chinese font:", (ROOT / "resources/fonts/NotoSansSC-Regular.otf").is_file())
    print("Bundled policies:", len(read_csv(ROOT / "data/policies.csv")))


def main():
    parser = argparse.ArgumentParser(description="AMR + VerbAtlas analysis toolkit for Chinese publishing AI policies")
    parser.add_argument("command", nargs="?", default="analyze",
                        choices=["prepare", "analyze", "reproduce", "full", "from-amr", "fetch-models", "doctor", "verify"])
    parser.add_argument("--corpus", type=Path, default=ROOT / "data/policies.csv")
    parser.add_argument("--mapping", type=Path, default=ROOT / "data/predicate_mapping.csv")
    parser.add_argument("--amr", type=Path, default=ROOT / "data/amr_predictions.csv")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--model-cache", type=Path, default=ROOT / ".models/hanlp")
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--check", action="store_true", help="Compare generated statistics with the bundled reference")
    args = parser.parse_args()
    if args.command == "doctor":
        doctor()
        return
    if args.command == "verify":
        verify_package()
        verify_corpus_contract()
        return
    if args.command == "fetch-models":
        from src.parse_amr import ensure_models
        ensure_models(args.model_cache)
        print("AMR checkpoints ready")
        return
    if args.check:
        verify_package()
        verify_corpus_contract()
    mode = "analyze" if args.command == "reproduce" else args.command
    output = (args.output or ROOT / "outputs" / mode).resolve()
    protected = [ROOT] + [ROOT / name for name in ["data", "resources", "src", "expected", "docs", "sources", "tests", "results_snapshot"]]
    if output in protected or any(path in output.parents for path in protected if path != ROOT):
        raise ValueError("Output must not overwrite package inputs or bundled results")
    output.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("MPLCONFIGDIR", str(output / ".matplotlib"))
    print("Preparing current corpus...", flush=True)
    expected_records = 252 if args.corpus.resolve() == (ROOT / "data/policies.csv").resolve() else None
    sentences, preprocess_audit = prepare(args.corpus, output, expected_records=expected_records)
    if args.command == "prepare":
        print(json.dumps(preprocess_audit, ensure_ascii=False))
        return
    if args.command == "full":
        from src.parse_amr import parse_fresh
        predictions = parse_fresh(sentences, output, model_cache=args.model_cache, batch_size=args.batch_size)
    else:
        predictions = validate_cached_predictions(sentences, read_csv(args.amr))
        write_csv(output / "amr_predictions.csv", predictions,
                  ["doc_id", "sentence_id", "sentence_sha256", "amr_string"])
        write_json(output / "amr_parse_audit.json", {
            "mode": "frozen_model_predictions", "source_amr_sha256": sha256(args.amr),
            "sentences": len(predictions),
            "nonempty_graphs": sum(row["amr_string"] not in ["", "<NAN>"] for row in predictions),
            "failures_or_no_edges": sum(row["amr_string"] in ["", "<NAN>"] for row in predictions),
            "every_sentence_content_hash_checked": True})
    print("Building event table...", flush=True)
    from src.events import build_events
    events, event_audit = build_events(predictions, output)
    print("Mapping VerbAtlas frames using the frozen decision table...", flush=True)
    from src.semantics import add_semantics
    enhanced, va_audit = add_semantics(events, sentences, args.mapping, output)
    print("Generating tables, figures and report...", flush=True)
    from src.analysis import run_analysis
    summary = run_analysis(enhanced, sentences, args.corpus,
                           {"preprocess": preprocess_audit, "events": event_audit, "va": va_audit}, output)
    versions = {}
    for name in ["numpy", "pandas", "igraph", "penman", "scikit-learn", "matplotlib", "networkx", "hanlp", "torch"]:
        try:
            versions[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            pass
    write_json(output / "run_environment.json", {"python": sys.version.split()[0], "dependencies": versions,
                                                "command": mode, "seed": 42,
                                                "corpus_sha256": sha256(args.corpus),
                                                "mapping_sha256": sha256(args.mapping)})
    if args.check:
        verify_results(summary)
    print("Done: {}".format(output), flush=True)
    print("Records={}, sentences={}, event_rows={}, VA_coverage={:.1%}".format(
        summary["corpus"]["records"], summary["corpus"]["sentences"], summary["amr"]["event_rows"],
        summary["va"]["event_frame_coverage"]), flush=True)


if __name__ == "__main__":
    main()
