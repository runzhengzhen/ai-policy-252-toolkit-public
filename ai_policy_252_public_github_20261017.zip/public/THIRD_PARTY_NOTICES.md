# 方法来源与第三方材料

## soteu叙事图代码与标签

`src/amr_graphs.py`、`src/helpers.py`、`src/constants.py`源于Pournaki与Willaert配套项目，保留本项目已有的边界保护，改为相对于代码定位资源。框架A/B/N标签来自其配套注释文件。

- 原文：https://doi.org/10.1057/s41599-025-06017-x
- 代码：https://github.com/pournaki/soteu-narratives
- 当前取得的上游代码快照未附独立LICENSE文件，本整理包不替原作者另行授予开放许可；引用、再分发范围及商业使用应遵从原作者的实际授权。本次保留作者及来源，不声称这些代码为本项目原创。

## VerbAtlas 1.1.0

- 作者：Andrea Di Fabio、Simone Conia、Roberto Navigli。
- 资源：https://verbatlas.org/
- 论文：https://aclanthology.org/D19-1058/
- VerbAtlas为CC BY-NC-SA 4.0；随包保留`resources/VerbAtlas-1.1.0/VERBATLAS-LICENSE.txt`、`LICENSES.txt`以及WordNet、BabelNet相关原始许可证。使用这些资源时应遵从各自许可，不能把整个包一概标为可任意商业使用。

## HanLP及模型

- 项目：https://github.com/hankcs/HanLP
- 中文AMR说明：https://hanlp.hankcs.com/docs/api/hanlp/pretrained/amr.html
- 大型模型权重由运行者从HanLP公开地址获取，未放入本ZIP。分词所需的小型字符表、词表、配置以及Mengzi分词器缓存为原资源的技术配套文件，保留其内容；权利归原作者与对应上游项目。
- Mengzi模型来源：https://huggingface.co/Langboat/mengzi-bert-base

## 字体

随包`resources/fonts/NotoSansSC-Regular.otf`来自Noto CJK项目，原许可证保存为`resources/fonts/OFL.txt`。

- 字体来源：https://github.com/notofonts/noto-cjk
- 未使用或再分发原电脑上的商业标题字体、核真录Logo或其他私人设计资产。

## 政策文本及研究编码

政策文本的原始来源页面记录于`data/policies.csv`。文本权利归相应原发布主体。本包提供研究整理数据、来源及分析流程，不改变原发布主体的权利。

自编整理与分析代码、冻结编码材料及第三方材料的来源分别记录。需要公开发布、另行许可或商业使用时，应按材料来源分别处理，不能用单一许可证覆盖全部内容。
